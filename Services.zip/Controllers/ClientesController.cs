﻿using Microsoft.AspNetCore.Mvc;
using OrdemServicoMvc.Services;

namespace OrdemServicoMvc.Controllers
{
    public class ClientesController : Controller
    {
        private readonly IClienteService _clienteService;

        public ClientesController(IClienteService clienteService)
        {
            _clienteService = clienteService;
        }

        public async Task<IActionResult> Index()
        {
            var clientes = await _clienteService.ObterTodosAsync();
            return View(clientes);
        }
    }
}